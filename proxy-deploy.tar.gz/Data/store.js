module.exports = {
  teamMap: {}
};