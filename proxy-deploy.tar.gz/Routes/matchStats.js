const express = require("express");
const axios = require("axios");

const router = express.Router();

const MATCH_STATS_API =
  "https://matchstats.sea.ffesports.com/api/match_stats/match_data";

router.post("/match_data", async (req, res) => {
  try {
    const upstreamResponse = await axios.post(MATCH_STATS_API, req.body, {
      timeout: 10000,
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      validateStatus: () => true,
    });

    return res.status(upstreamResponse.status).json(upstreamResponse.data);
  } catch (err) {
    console.error("Match stats proxy failed:", err.message);
    return res.status(502).json({
      success: false,
      message: "Failed to fetch match stats",
      error: err.message,
    });
  }
});

module.exports = router;
